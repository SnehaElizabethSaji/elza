package com.healthcare.admin.junit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.healthcare.admin.dao.AdminDao;
import com.healthcare.admin.dao.AdminDaoImpl;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class TestClass {
	AdminDao dao=null;
	
	
	@Before
	public void setUp()
	{
		dao=new AdminDaoImpl();
		
	}
	@After
	public void tearDown()
	{
		dao=null;
	}
    @Test

    public void testEquals()
    {
    	
		Assert.assertEquals(true,dao.bookAppointment(101));
    	
    	}

    @Test

    public void testNotEquals()

    {

       Assert.assertNotNull(false);

    }
	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
