package com.healthcare.admin.dao;

public interface AdminDao {
	
		public boolean bookAppointment(int id );
		public void approveMethod();
		
	}


