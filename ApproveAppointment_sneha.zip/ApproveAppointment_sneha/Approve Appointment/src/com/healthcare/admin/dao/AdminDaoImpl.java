package com.healthcare.admin.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.healthcare.admin.db.DbConn;

public class AdminDaoImpl implements AdminDao {
	public boolean  bookAppointment(int id)  {
		try{
			Connection conn=DbConn.getConnection();	
			Statement st=conn.createStatement();
			System.out.println("Appointment id's from the test center ");
				System.out.println("Appointment ID's which are not  approved are :");
				ResultSet rs=st.executeQuery("select * from appointment where not approved='yes'");
				while(rs.next())
				{
					System.out.println(rs.getString(2)+" " +rs.getString(3));
				}
				approveMethod();
				
		}
		catch (SQLException | ClassNotFoundException | NumberFormatException  e) {
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return true;
	}

	public void approveMethod()
	{
			try{
				Connection conn=DbConn.getConnection();	
				PreparedStatement pst1=conn.prepareStatement("update appointment set approved=? where app_id=?");
				BufferedReader inp = new BufferedReader (new InputStreamReader(System.in));
				System.out.println("Enter app_id,Status to update");
				int i=Integer.parseInt(inp.readLine());
				String  status= inp.readLine();
				pst1.setInt(2,i);
				pst1.setString(1,status);
				pst1.execute();
				System.out.println("Updated Successfully");
			}
				catch(SQLException|ClassNotFoundException|IOException e)
			{
						e.getStackTrace();
			} 
			catch(Exception e)
			{
				e.getStackTrace();
			}
	}

	

	}



