package com.healthcare.admin.dto;

public class AdminDto {
	String appId;
	public AdminDto() {}
	public AdminDto(String appId) {
		this.appId = appId;
	}
	public String getAppid() {
		return appId;
	}
	public void setAppid(String appid) {
		this.appId = appid;
	}
	
	
	

}
