package com.healthcare.admin.service;

public interface AdminService 
{
public boolean bookAppointment(int id) ;
	
}
