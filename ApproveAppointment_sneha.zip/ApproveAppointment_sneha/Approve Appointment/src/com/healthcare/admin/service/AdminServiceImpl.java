package com.healthcare.admin.service;

import com.healthcare.admin.dao.AdminDaoImpl;

public class AdminServiceImpl implements AdminService  {
	AdminDaoImpl approveDao=new AdminDaoImpl();
	public boolean bookAppointment(int id)
	{
		boolean result=approveDao.bookAppointment(id);
		return result;

}
}
