package com.healthcare.admin.appl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.healthcare.admin.dao.AdminDao;
import com.healthcare.admin.dao.AdminDaoImpl;

public class AdminApproveAppl 
{
		public static void main(String[] args)  {
			System.out.println("MENU");
			System.out.println("1.To display all test centers");
			System.out.println("2.exit");
			@SuppressWarnings("resource")
			Scanner s1=new Scanner(System.in);
			AdminDao service=new AdminDaoImpl();
			try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","scott","tiger");
			int var=s1.nextInt();
			do{	
			switch(var)
			{
			 case 1:
			 {
				try
				{
				Statement smt= conn.createStatement();
				String q="select center_id from diagnostic_center";
				ResultSet rs=((java.sql.Statement) smt).executeQuery(q);
				System.out.println("Test Centers :");
				if(rs.next())
				{
					do{
						System.out.println(rs.getInt(1));
					}while(rs.next());
				}
				System.out.println("Enter test center to display all appointments");
			    int id1= s1.nextInt();

				boolean result=service.bookAppointment(id1);
				if(result)
					System.out.println("booking is success");
			    }
				catch(SQLException e)
				{
					e.getStackTrace();
				} 
				catch (NumberFormatException e) {
					
					e.printStackTrace();
				} 
				
				break;
			 }
			case 2:
			 {
				 System.out.println("Terminated");
				System.exit(0);
				
			 }
			 default :
				 System.out.println("Invalid Option");
			}
			System.out.println("choose ur option");
			var= s1.nextInt();
		}while(var<=2);
			}
			catch(SQLException|ClassNotFoundException e)
			{
				e.getStackTrace();
			}

	}
	}

