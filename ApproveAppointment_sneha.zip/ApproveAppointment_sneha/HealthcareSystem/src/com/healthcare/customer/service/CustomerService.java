package com.healthcare.customer.service;

import com.healthcare.customer.dto.CustomerDto;

import java.math.BigInteger;

import com.healthcare.customer.dao.CustomerDao;

public class CustomerService {
 static CustomerDao dao=new CustomerDao();
	public void showCenter(String uname) throws Exception {
		CustomerDto bean=new CustomerDto();
		bean.setUname(uname);
		// TODO Auto-generated method stub
		dao.showCenter(uname);
		
		
	}
	public void view(String string) throws Exception {
		// TODO Auto-generated method stub
		dao.view(string);
		
	}
	public void showTests(String center) {
		// TODO Auto-generated method stub
		dao.showTests(center);
	}
	public Long makeAppointment(String uname, String testID, String test) {
		return null;
	}
	
	

}
