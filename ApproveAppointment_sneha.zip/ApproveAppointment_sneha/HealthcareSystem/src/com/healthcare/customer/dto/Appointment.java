package com.healthcare.customer.dto;
import java.sql.Date;
public class Appointment 
{
	String userId;
	int appId;
	TestClass test;
	String centerId;
	Date doa;
	public Appointment(String userId, int appId, TestClass test, String centerId, Date doa) {
		super();
		this.userId = userId;
		this.appId = appId;
		this.test = test;
		this.centerId = centerId;
		this.doa = doa;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	public TestClass getTest() {
		return test;
	}
	public void setTest(TestClass test) {
		this.test = test;
	}
	public String getCenterId() {
		return centerId;
	}
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}
	public Date getDoa() {
		return doa;
	}
	public void setDoa(Date doa) {
		this.doa = doa;
	}
	
	
}
