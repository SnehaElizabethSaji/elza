package com.healthcare.customer.dto;

import java.util.List;

public class CenterClass 
{
	private String centerName,centerId;
	private List<TestClass> testList;
	private List<Appointment> appointmentList;
	public CenterClass(String centerName, String centerId, List<TestClass> testList,
			List<Appointment> appointmentList) {
		super();
		this.centerName = centerName;
		this.centerId = centerId;
		this.testList = testList;
		this.appointmentList = appointmentList;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public String getCenterId() {
		return centerId;
	}
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}
	public List<TestClass> getTestList() {
		return testList;
	}
	public void setTestList(List<TestClass> testList) {
		this.testList = testList;
	}
	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}
	public void setAppointmentList(List<Appointment> appointmentList) {
		this.appointmentList = appointmentList;
	}
	 

}
