package com.healthcare.customer.dto;
import java.util.HashMap;
public class TestClass 
{
	private String centerId;
	private HashMap<String, String> testList;
	public TestClass(String centerId, HashMap<String, String> testList) {
		this.centerId = centerId;
		this.testList = testList;
	}
	public TestClass() {
	}
	public String getCenterId() {
		return centerId;
	}
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}
	public HashMap<String, String> getTestList() {
		return testList;
	}
	public void setTestList(HashMap<String, String> testList) {
		this.testList = testList;
		
	}
}
