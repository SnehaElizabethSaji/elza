
package com.healthcare.customer.dto;

public class CustomerDto {
	private String uname;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

}

