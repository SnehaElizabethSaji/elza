package com.healthcare.customer.appl;

import java.math.BigInteger;
import java.util.Scanner;
import com.healthcare.customer.dto.CustomerDto;
import com.healthcare.customer.service.CustomerService;

public class CustomerAppl {
	static CustomerService service = new CustomerService();

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Enter your option");
			System.out.println("1.Make Appointment");
			System.out.println("2.View Appointment");
			int opt = sc.nextInt();
			if (opt == 1) {
				System.out.println("Enter your name");
				String uname = sc.next();
				System.out.println("select center");
				service.showCenter(uname);
				String center = sc.nextLine();
				System.out.println("Select the test:");
				service.showTests(center);
				String test =sc.nextLine();
				System.out.println("Select the testID:");
				String testID =sc.nextLine();
				System.out.println("");
				Long appointmentId = service.makeAppointment(uname,testID,test);

			} else
				System.out.println("to see the appointment details");
			System.out.println("Enter appointment id");
			service.view(sc.next());

		}
	}

}
