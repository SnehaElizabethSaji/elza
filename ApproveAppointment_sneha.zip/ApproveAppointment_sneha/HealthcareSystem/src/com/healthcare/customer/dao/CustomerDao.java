package com.healthcare.customer.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.healthcare.customer.dto.CustomerDto;
import com.healthcare.customer.dto.TestClass;

public class CustomerDao {
	CustomerDto bean = new CustomerDto();

	Scanner sc = new Scanner(System.in);
	static int count = 0, count1 = 0, count2 = 0;
	static String centername = "";
	static String tests = "";

	public void showCenter(String uname) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pst = null;
		conn = DbClass.getConnection();
		String str = "select centername from center";
		pst = conn.prepareStatement(str);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			centername = rs.getString(1);
			System.out.println(rs.getString(1));
		}
		String center = sc.next();
		System.out.println("select test");
		String str1 = "select * from center";
		pst = conn.prepareStatement(str1);
		ResultSet rs1 = pst.executeQuery();
		while (rs1.next()) {
			System.out.println(rs1.getString(3));
		}
		String test = sc.next();
		System.out.println("select date and time");
		String a = "09/3/2020 & 9:00 AM";
		String b = "09/3/2020 & 11:00 AM";
		String c = "09/3/2020 & 2:00 PM";
		System.out.println("1. " + a);
		System.out.println("2. " + b);
		System.out.println("3. " + c);

		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		if (ch == 1 && count == 0) {
			System.out.println("appointment booked");
			count++;
		}
		if (ch == 2 && count1 == 0) {
			System.out.println("appointment booked");
			count1++;
		}
		if (ch == 3 && count2 == 0) {
			System.out.println("appointment booked");
			count2++;
		}

		String str2 = ("insert into appointment values(id2.nextval,?,?,?,?)");
		pst = conn.prepareStatement(str2);
		pst.setString(1, uname);
		pst.setString(2, center);
		pst.setString(3, test);
		if (count == 1)
			pst.setString(4, a);
		if (count1 == 1)
			pst.setString(4, b);
		if (count2 == 1)
			pst.setString(4, c);
		pst.executeUpdate();
		String str3 = ("select * from appointment");
		pst = conn.prepareStatement(str3);
		ResultSet rs2 = pst.executeQuery();
		while (rs2.next()) {
			System.out.println(rs2.getString(1));
		}

	}

	public void view(String string) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pst = null;
		conn = DbClass.getConnection();
		String str2 = "select * from appointment";
		pst = conn.prepareStatement(str2);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			if (rs.getString(1).equals(string))
				System.out.println("Appointment id :" + rs.getString(1) + "\nUser name " + rs.getString(2)
						+ "\ncentre name " + rs.getString(3) + "\nTest name " + rs.getString(4) + "\nDate and Time "
						+ rs.getString(5));
		}

	}

	public void showTests(String center) 
	{
		Connection conn = null;
		PreparedStatement pst = null;
		HashMap<String, String> testList = null;
		try {
			conn = DbClass.getConnection();
			String str2 = "select * from test?";
			pst = conn.prepareStatement(str2);
			pst.setString(1, center);
			ResultSet rs = pst.executeQuery();
			TestClass tc = new TestClass();
			testList = new HashMap<>();
			while (rs.next()) {
				tc.setCenterId(rs.getString(1));
				String id =rs.getString(2);
				String name=rs.getString(3);
				testList.put(id, name);
		}
			tc.setTestList(testList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		Set<Entry<String, String>> set = testList.entrySet();
		Iterator<Entry<String, String>> itr = set.iterator();
		while(itr.hasNext())
		{
			Map.Entry<String, String> value = (Entry<String,String>)itr.next();
			System.out.println(value.getKey()+" "+value.getValue());
		}
	}
}